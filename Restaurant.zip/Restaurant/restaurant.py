import os
import random
import create_pattern as cp

os.chdir(r"E:\Python\PracticeSet\NAVTCC\restaurant")
a = ""
admin = {"name":"urooj","pin":124}

# menu dictionary
restaurant = {
    "Breakfast": [
        {"id": 1, "name": "Omelette", "price": 100},
        {"id": 2, "name": "Paratha", "price": 100},
        {"id": 3, "name": "Tea", "price": 50},
        {"id": 4, "name": "Coffee", "price": 100},
        {"id": 5, "name": "Halwa Puri", "price": 200}
    ],
    "Chinese": [
        {"id": 6, "name": "Chowmein", "price": 1000},
        {"id": 7, "name": "Chicken Fried Rice", "price": 800},
        {"id": 8, "name": "Shashlik", "price": 1300},
        {"id": 9, "name": "Momos", "price": 400},
        {"id": 10, "name": "Ramen", "price": 1200}
    ],
    "Starters": [
        {"id": 11, "name": "Chicken Wings", "price": 600},
        {"id": 12, "name": "Spring Rolls", "price": 500},
        {"id": 13, "name": "Cheese Balls", "price": 550}
    ],
    "Desi": [
        {"id": 14, "name": "Biryani", "price": 900},
        {"id": 15, "name": "Nihari", "price": 1200},
        {"id": 16, "name": "Haleem", "price": 1000},
        {"id": 17, "name": "Paye", "price": 1300}
    ],
    "Sweets": [
        {"id": 18, "name": "Fudge Cake", "price": 1600},
        {"id": 19, "name": "Brownie", "price": 400},
        {"id": 20, "name": "Black Forest Cake", "price": 1400},
        {"id": 21, "name": "Gulab Jamun", "price": 300}
    ],
    "Drinks": [
        {"id": 22, "name": "Mountain Dew", "price": 150},
        {"id": 23, "name": "Mojito", "price": 350},
    ],
    "Chicken Special": [
        {"id": 24, "name": "Chicken Handi", "price": 1200},
        {"id": 25, "name": "Chicken Karahi", "price": 1400}
    ],
    "Bar BQ": [
        {"id": 26, "name": "Chicken Tikka", "price": 500},
        {"id": 27, "name": "Beef Seekh Kebab", "price": 600},
        {"id": 28, "name": "Chicken Malai Boti", "price": 700}
    ],
    "Salad": [
        {"id": 29, "name": "Russian Salad", "price": 450},
        {"id": 30, "name": "Green Salad", "price": 250}
    ]
}

def update_menu_file():
    menuItems = ""
    for cat, items in restaurant.items():
        menuItems += f"\n{cat}:\n------------------------------------------\n"
        for item in items:
            menuItems += f"{item['id']}: {item['name']} ...... Price: {item['price']}\n"
    with open("menu.txt", "w") as resFile:
        resFile.write(menuItems)

update_menu_file()

def readMenu():
    print("\n\n************ Restaurant Menu ************\n")
    with open("menu.txt","r") as file:
        res_menu = file.read()
        print(res_menu)

# main code
print("\t\t\t\t\t\tWelcome To")
var = cp.word("Restaurant","*")

user = input("Are you admin on user. Enter below\n")

if user.lower() == "admin":
    admin_name = input("Enter your name: ")
    admin_pin = int(input("Enter your pin code: "))

    if admin['name'] != admin_name:
        print("Username is wrong")
    elif admin['pin'] != admin_pin:
        print("Pin is wrong")
    else:
        while True:
            admin_input = int(input('''
Do you want to 
    1: View Menu
    2: Add item to Menu
    3: Remove Item From Menu
    4: Update Item to Menu
    5: View Customer Details
    6: Exit
'''))
            if admin_input == 1:
                readMenu()
            elif admin_input == 2:
                n_cat = input("Enter Category: ")
                n_id = int(input("Enter Item ID: "))
                n_name = input("Enter Item Name: ")
                n_price = int(input("Enter Item Price: "))
                new_item = {"id":n_id, "name":n_name,"price":n_price}
                if n_cat in restaurant:
                    restaurant[n_cat].append(new_item)
                    print(f"✅ Added to existing category: {n_cat}")
                else:
                    restaurant[n_cat] = [new_item]
                    print(f"✅ New category '{n_cat}' created and item added")
                update_menu_file()

            elif admin_input == 3:
                rId = int(input("Enter id to remove item: "))
                found = False
                for cat, items in restaurant.items():
                    for item in items:
                        if item['id'] == rId:
                            items.remove(item)
                            print("✅ Item removed successfully")
                            found = True
                            break
                    if found:
                        break
                if not found:
                    print("❌ ID not found!")
                update_menu_file()

            elif admin_input == 4:
                update_ask = input("Do you want to update price of item or name?\nIf you want to update price enter 'P' or if for name enter 'N': ").upper()
                u_id = int(input("Enter id to update item: "))
                found = False
                if update_ask == "P":
                    new_price = int(input("Enter new price of the item: "))
                    for cat, items in restaurant.items():
                        for item in items:
                            if item['id'] == u_id:
                                item['price'] = new_price
                                print("✅ Price updated")
                                found = True
                                break
                        if found:
                            break
                elif update_ask == "N":
                    new_name = input("Enter new name of the item: ")
                    for cat, items in restaurant.items():
                        for item in items:
                            if item['id'] == u_id:
                                item['name'] = new_name
                                print("✅ Name updated")
                                found = True
                                break
                        if found:
                            break
                else:
                    print("Invalid input")
                if not found:
                    print("❌ Given id not exist!")
                update_menu_file()

            elif admin_input == 5:
                with open("userBill.txt","r") as readbill:
                    rb = readbill.read()
                    print(rb)
            elif admin_input == 6:
                exit()
elif user.lower() == "user":
    readMenu()

    order = []
    bill = ""
    total_bill = 0

    while True:
        try:
            m_id = int(input("Select items from the menu by using their id and enter 0 for end order: "))

            if m_id == 0:
                print("Thank you for your order!")
                break

            itemFound = False
            for cat, items in restaurant.items():
                for item in items:
                    if item['id'] == m_id:
                        order.append(item)
                        bill += f"{item['name']} ---------- {item['price']}\n"
                        total_bill += item['price']
                        itemFound = True
                        break
                if itemFound:
                    break

            if m_id < 1 or m_id > 30:
                raise ValueError("Invalid item ID! Please try again.")
        except ValueError as e:
            print(e)

    if order:
        ranId = random.randint(1,100)
        cusId = "cus"+str(ranId)
        with open("userBill.txt", "a") as userBill:
            userBill.write("\n***** Customer Bill *****\n")
            userBill.write(f"Customer ID: {cusId}\n")
            userBill.write("Item Names\t\t\tPrice\n")
            userBill.write(bill)
            userBill.write(f"\nTotal Bill: {total_bill} Rs\n")

        print("\n***** Your Bill *****")
        print("Item Names\t\tPrice")
        print(bill)
        print(f"\nTotal Bill: {total_bill} Rs")

    else:
        print("No items were ordered.")