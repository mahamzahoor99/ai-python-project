
print("***** ATM Menu *****")
print("--------------------")
user = (input("Enter Username: "))
pass1= (input("Enter Password: "))

if user == "Aisha" and pass1 == "12345":
    print("\n-----Login Successful-----")
else:
    print("Account is not registered")

print("\n1. Withdraw Money")
print("2. Deposit Money")
print("3. Check Balance")
print("4. Transaction History") 
print("5. Exit\n") 
w2_amount=0
d2_amount=0
balance = 0
while True:
    choice = int(input("Enter your choice: "))
    if choice == 1:
        w_amount = int(input("Enter amount to withdraw: "))
        if w_amount > balance:
            print(f"Insufficient balance. The current balance is {balance}")
        else:
            balance -= w_amount
            print(f"You withdraw {w_amount}. The new balance is {balance}")
            input1 = input("Do you want to withdraw more amount?? (y/n)")
            if input1 == "y":
                w2_amount = int(input("Enter amount to withdraw: "))
                if w2_amount > balance:
                    print(f"Insufficient balance. The current balance is {balance}")
                else:
                    balance -= w2_amount
                    print(f"You withdraw {w2_amount}. The new balance is {balance}")
            elif input1 == "n":
                print(f"Total balance is {balance} ")
    elif choice == 2:
        d_amount = int(input("Enter amount to deposit: "))
        balance += d_amount
        print(f"You deposited {d_amount}. The new balance is {balance}")
        input2 = input("Do you want to deposit more amount?? (y/n)")
        if input2 == "y":
            d2_amount = int(input("Enter amount to deposit: "))
            balance += d2_amount
            print(f"You deposited {d2_amount}. The new balance is {balance}")
        elif input2 == "n":
            print(f"Total balance is {balance} ")
    elif choice == 3:
        print(f"Your balance is {balance}")
    elif choice == 4:
        print("Your Transaction History:")
        td_amount = d_amount + d2_amount
        print(f"You Deposited {td_amount}")
        tw_amount = w_amount + w2_amount
        print(f"You Withdraw {tw_amount}")
        print(f"Your balance is {balance}")
    elif choice == 5:
        print("----------------------------")
        print("Thank you for using the ATM!")
        print("----------------------------")

        break
    else:
        print("Invalid choice. Please try again")