
a=1
b=3
c=3
d=4
e=5
n=2
m=4
q=2
p=3
y=5
z=3
x=2
r=1

e1 = a + 2 * b
print(e1)
e2 = 1 - (b/2)
print(e2)
e3 = 24 * b - c * d
print(e3)
e4 = x + (y/(2-3*z))*((x/4) - 7*c)
print(e4)
e5 = (n*(n+1))/2
print(e5)
e6 = 2*x * (y-z)
print(e6)
e7 = 2 *(x-y*(z-((3/2)*x)))
print(e7)
e8 = 3 - ((2*x)/(4-x))
print(e8)
e9 = (7*c)/(4-3*((x)/(4*y)))
print(e9)
e10= -5*(((1/4)*p) - ((2/5)*q) + ((1/2)*r))
print(e10)
